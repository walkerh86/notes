#!/usr/bin/python

import os
import sys
import ConfigParser
from PIL import Image

def do_cmd(cmd):
    print cmd
    os.system(cmd)
    
LOGO_DIR = 'logo'
SYSTEM_DIR = 'system'
RECOVERY_DIR = 'recovery'

GEN_LOGO_BIN = 'gen_logo.py'
GEN_SYSTEM_BIN = 'gen_system_img.py'
GEN_RECOVERY_BIN = 'gen_recovery_img.py'

CUST_OUT = ''
CUST_OUT_BOOTLOGO = ''
CUST_UBOOT_LOGO = ''
CUST_KERNEL_LOGO = ''
CUST_CONFIG = ''
CUST_SYSTEM = ''
CUST_SYSTEM_APPBACKUP = ''
CUST_DATA = ''

#init configs
CONF_SECTION_COM = 'common'
CONF_SECTION_CUST = 'custom'

boot_orientation = 'land'
src_bin_dir = ''
cust_dir = ''
cust_props = ''

def show_usage():
    print 'Usage: cust_rom.py <src bin dir> <cust dir>'
    
def init_check_argvs():
    global src_bin_dir
    global cust_dir
    global CUST_OUT
    global CUST_OUT_BOOTLOGO
    global CUST_UBOOT_LOGO
    global CUST_KERNEL_LOGO
    global CUST_CONFIG
    global CUST_SYSTEM
    global CUST_SYSTEM_APPBACKUP
    global CUST_DATA
    
    if len(sys.argv) < 3:
        show_usage()
        sys.exit()

    src_bin_dir = sys.argv[1]
    cust_dir = sys.argv[2]
    CUST_OUT = os.path.join(cust_dir,'out')
    CUST_OUT_BOOTLOGO = os.path.join(CUST_OUT,'boot_logo')
    CUST_UBOOT_LOGO = os.path.join(cust_dir,'uboot.bmp')
    CUST_KERNEL_LOGO = os.path.join(cust_dir,'kernel.bmp')
    CUST_CONFIG = os.path.join(cust_dir,'cust_config')
    CUST_SYSTEM = os.path.join(cust_dir,'system')
    CUST_SYSTEM_APPBACKUP = os.path.join(CUST_SYSTEM,'appbackup')
    CUST_DATA = os.path.join(cust_dir,'data')
    
def conf_parser_get(parse, section, option):
    try:
        return parse.get(section,option)
    except:
        return ''
        
def init_configs():
    global boot_orientation
    global cust_props
    if not os.path.exists(CUST_CONFIG):
        return
    
    conf_parser = ConfigParser.ConfigParser()
    conf_parser.read(CUST_CONFIG)

    cust_options = []
    for option in conf_parser.options(CONF_SECTION_CUST):
        value = conf_parser_get(conf_parser,CONF_SECTION_CUST,option)
        if len(value) > 0:
            cust_options.append('='.join([option,value]))
    cust_props = ' '.join(cust_options)
    #print cust_props
        
#check dep
modify_logo = False
modify_system = False
modify_userdata = False
modify_recovery = False

def check_logo_dep():
    if os.path.exists(CUST_UBOOT_LOGO):
        return True
    if os.path.exists(CUST_KERNEL_LOGO):
        return True    
    return False

def check_prop_dep():
    if len(cust_props) > 0:
        return True
    return False

def check_system_dep():
    if os.path.exists(CUST_UBOOT_LOGO):
        return True
    if os.path.exists(CUST_KERNEL_LOGO):
        return True
    if os.path.exists(CUST_SYSTEM):
        return True
    if cmp(boot_orientation,'port') == 0:
        return True
    return check_prop_dep()

def check_userdata_dep():
    if os.path.exists(CUST_DATA):
        return True
    if os.path.exists(CUST_SYSTEM_APPBACKUP):
        return True
    return False

def check_recovery_dep():
    return check_prop_dep()

def init_check_dep():
    global modify_logo
    global modify_system
    global modify_userdata
    global modify_recovery
    modify_logo = check_logo_dep()
    modify_system = check_system_dep()
    modify_userdata = check_userdata_dep()
    modify_recovery = check_recovery_dep()
    
def init_check():
    if not os.path.exists(src_bin_dir):
        sys.exit('src bin dir '+src_bin_dir+' not exists')

    if modify_system and not os.path.exists(os.path.join(src_bin_dir,'system.img')):
        sys.exit('system.img not exists')
        
    if modify_userdata and not os.path.exists(os.path.join(src_bin_dir,'userdata.img')):
        sys.exit('userdata.img not exists')

    if modify_recovery and not os.path.exists(os.path.join(src_bin_dir,'recovery.img')):
        sys.exit('recovery.img not exists')
    
    if os.path.exists(CUST_OUT):
        do_cmd('rm -rf '+CUST_OUT)
    os.mkdir(CUST_OUT)

    do_cmd('sudo chmod 777 '+os.path.join(SYSTEM_DIR,GEN_SYSTEM_BIN))
    do_cmd('sudo chmod 777 '+os.path.join(RECOVERY_DIR,GEN_RECOVERY_BIN))
    do_cmd('sudo chmod 777 '+os.path.join(LOGO_DIR,GEN_LOGO_BIN))
    
#gen logo
def gen_logo_img():
    os.chdir(LOGO_DIR)
    tmp_cust_out = os.path.join('..',CUST_OUT)
    gen_logo_cmd = ' '.join(['python',GEN_LOGO_BIN,os.path.join('..',cust_dir),tmp_cust_out])
    do_cmd(gen_logo_cmd)
    os.chdir('..')

def unpack_system_img():
    os.chdir(SYSTEM_DIR)
    src_img = os.path.join('..',src_bin_dir,'system.img')
    unpack_system_img_cmd = ' '.join(['python',GEN_SYSTEM_BIN,'--system','-unpack',src_img])
    do_cmd(unpack_system_img_cmd)
    os.chdir('..')

def repack_system_img():
    os.chdir(SYSTEM_DIR)
    dst_img = os.path.join('..',CUST_OUT,'system.img')
    repack_system_img_cmd = ' '.join(['python',GEN_SYSTEM_BIN,'--system','-repack',dst_img])
    do_cmd(repack_system_img_cmd)
    os.chdir('..')

def unpack_userdata_img():
    os.chdir(SYSTEM_DIR)
    src_img = os.path.join('..',src_bin_dir,'userdata.img')
    unpack_system_img_cmd = ' '.join(['python',GEN_SYSTEM_BIN,'--userdata','-unpack',src_img])
    do_cmd(unpack_system_img_cmd)
    os.chdir('..')

def repack_userdata_img():
    os.chdir(SYSTEM_DIR)
    dst_img = os.path.join('..',CUST_OUT,'userdata.img')
    repack_system_img_cmd = ' '.join(['python',GEN_SYSTEM_BIN,'--userdata','-repack',dst_img])
    do_cmd(repack_system_img_cmd)
    os.chdir('..')

def unpack_recovery_img():
    os.chdir(RECOVERY_DIR)
    src_img = os.path.join('..',src_bin_dir,'recovery.img')
    unpack_img_cmd = ' '.join(['python',GEN_RECOVERY_BIN,'-unpack',src_img])
    do_cmd(unpack_img_cmd)
    os.chdir('..')

def repack_recovery_img():
    os.chdir(RECOVERY_DIR)
    dst_img = os.path.join('..',CUST_OUT,'recovery.img')
    repack_img_cmd = ' '.join(['python',GEN_RECOVERY_BIN,'-repack',dst_img])
    do_cmd(repack_img_cmd)
    os.chdir('..')
    
def unpack_imgs():
    if modify_system:
        unpack_system_img()
    if modify_recovery:
        unpack_recovery_img()
    if modify_userdata:
        unpack_userdata_img()

def repack_imgs():
    if modify_system:
        repack_system_img()
    if modify_recovery:
        repack_recovery_img()
    if modify_userdata:
        repack_userdata_img()

def do_modify_logo():
    if not modify_logo:
        return
    #gen logo.bin & boot_logo
    gen_logo_img()
    
    os.chdir(SYSTEM_DIR)
    modify_logo_cmd = ' '.join(['python',GEN_SYSTEM_BIN,'--system','-modify','logo',os.path.join('..',CUST_OUT)])
    do_cmd(modify_logo_cmd)
    os.chdir('..')

def do_modify_prop_cb(src_prop, tmp_prop, prop_list):
    props_dict = {}
    for prop in prop_list:
        if len(prop.strip()) == 0:
            continue
        prop_pair = prop.split('=')
        if len(prop_pair) != 2:
            continue
        props_dict[prop_pair[0]] = prop_pair[1]
        
    src_prop_f = open(src_prop,'r')
    tmp_prop_f = open(tmp_prop,'w')
    for line in src_prop_f:
        strip_line = line.strip()
        line_pair = strip_line.split('=')
        if len(line_pair) == 2 and props_dict.has_key(line_pair[0]):
            tmp_prop_f.write(line_pair[0]+'='+props_dict[line_pair[0]]+'\n')
            props_dict.pop(line_pair[0])
        else:
            tmp_prop_f.write(line)
    if len(props_dict) > 0:
        tmp_prop_f.write('\n#\n')
        tmp_prop_f.write('# twd auto added\n')
        tmp_prop_f.write('#\n')
    for (k,v) in  props_dict.items():
        if len(v) > 0:
            tmp_prop_f.write(k+'='+v+'\n')
        
    src_prop_f.close()
    tmp_prop_f.close()
    do_cmd(' '.join(['sudo mv',tmp_prop,src_prop]))
    
def do_modify_prop():
    if not check_prop_dep():
        return
    os.chdir(SYSTEM_DIR)
    modify_props_cmd = ' '.join(['python',GEN_SYSTEM_BIN,'--system','-modify','props',cust_props])
    do_cmd(modify_props_cmd)
    os.chdir('..')
    os.chdir(RECOVERY_DIR)
    modify_props_cmd = ' '.join(['python',GEN_RECOVERY_BIN,'-modify','props',cust_props])
    do_cmd(modify_props_cmd)
    os.chdir('..')

def do_modify_preinstall_app():
    preinstall_dir = CUST_SYSTEM_APPBACKUP
    if not os.path.exists(preinstall_dir):
        return
    preinstall_apps = os.listdir(preinstall_dir)
    if len(preinstall_apps) == 0:
        return
    #gen .keep_list & .restore_list
    data_app_dir = os.path.join(CUST_DATA,'app')
    if not os.path.exists(data_app_dir):
        do_cmd(' '.join(['sudo mkdir -p',data_app_dir]))
        do_cmd('sudo chmod 777 '+data_app_dir)
    keep_list = []
    for app in preinstall_apps:
        keep_list.append('/data/app/'+app+'\n')
    keep_list_f = open(os.path.join(data_app_dir,'.keep_list'),'w')
    keep_list_f.writelines(keep_list)
    keep_list_f.close()
    restore_list = []
    for app in preinstall_apps:
        restore_list.append('/system/appbackup/'+app+'\n')
    restore_list_f = open(os.path.join(data_app_dir,'.restore_list'),'w')
    restore_list_f.writelines(restore_list)
    restore_list_f.close()

    do_cmd(' '.join(['sudo cp -r',os.path.join(preinstall_dir,'*'),data_app_dir]))

def do_modify_overlay():
    if os.path.exists(CUST_SYSTEM):
        os.chdir(SYSTEM_DIR)
        modify_overlay_cmd = ' '.join(['python',GEN_SYSTEM_BIN,'--system','-modify','overlay',os.path.join('..',CUST_SYSTEM)])
        do_cmd(modify_overlay_cmd)
        os.chdir('..')
    if os.path.exists(CUST_DATA):
        os.chdir(SYSTEM_DIR)
        modify_overlay_cmd = ' '.join(['python',GEN_SYSTEM_BIN,'--userdata','-modify','overlay',os.path.join('..',CUST_DATA)])
        do_cmd(modify_overlay_cmd)
        os.chdir('..')
    if cmp(boot_orientation,'port') == 0:
        ORIENTATION_SYSTEM = os.path.join('port','system')
        os.chdir(SYSTEM_DIR)
        modify_overlay_cmd = ' '.join(['python',GEN_SYSTEM_BIN,'--system','-modify','overlay',os.path.join(ORIENTATION_SYSTEM)])
        do_cmd(modify_overlay_cmd)
        os.chdir('..')
    
def modify_imgs():
    do_modify_logo()
    do_modify_prop()
    #do_modify_preinstall_app just for gen overlay dir data/app
    do_modify_preinstall_app()
    #do_modify_preinstall_app must before do_modify_overlay
    do_modify_overlay()

def main(argv):
    init_check_argvs()
    init_configs()
    init_check_dep()
    init_check()
    unpack_imgs()
    modify_imgs()
    repack_imgs()
    
if __name__ == '__main__':
    main(sys.argv)
