#!/usr/bin/python

import os
import sys
from PIL import Image

def show_usage():
    print \
'Usage:\
    cmd <logo_dir> <src_logo_dir> <out_path>'

if len(sys.argv) < 3:
    show_usage()
    sys.exit()

#logo_dir=sys.argv[1]
src_logo_dir = sys.argv[1]
out_path = sys.argv[2]

BMP_TO_RAW = os.path.join('tools','bmp_to_raw')
ZPIPE = os.path.join('tools','zpipe')
MKIMAGE = os.path.join('tools','mkimage')

UBOOT_LOGO_FN = os.path.join(src_logo_dir,'uboot.bmp')
KERNEL_LOGO_FN = os.path.join(src_logo_dir,'kernel.bmp')
if not os.path.exists(KERNEL_LOGO_FN):
    KERNEL_LOGO_FN = UBOOT_LOGO_FN

UBOOT_LOGO_FN2 = os.path.join(src_logo_dir,'uboot2.bmp')
KERNEL_LOGO_FN2 = os.path.join(src_logo_dir,'kernel2.bmp')
if not os.path.exists(KERNEL_LOGO_FN2):
    KERNEL_LOGO_FN2 = UBOOT_LOGO_FN2 

logo_bin = os.path.join(out_path,'logo.bin')
boot_logo = os.path.join(out_path,'boot_logo')
boot_logo2 = os.path.join(out_path,'boot_logo2')

logo_dir = ''
check_resolution_img = ''
if os.path.exists(UBOOT_LOGO_FN):
    check_resolution_img = UBOOT_LOGO_FN
elif os.path.exists(KERNEL_LOGO_FN):
    check_resolution_img = KERNEL_LOGO_FN
elif os.path.exists(UBOOT_LOGO_FN2):
    check_resolution_img = UBOOT_LOGO_FN2
elif os.path.exists(KERNEL_LOGO_FN2):
    check_resolution_img = KERNEL_LOGO_FN2
if len(check_resolution_img) > 0:
    im = Image.open(check_resolution_img)
    if im.size[0] == 800 or im.size[1] == 800:
        logo_dir = 'wvgalnl'
    else:
        logo_dir = 'wsvganl'
    print 'logo resolution = '+logo_dir

if len(logo_dir) == 0:
    print 'logo resolution not define'
    sys.exit()
    
RESOURCE_OBJ_LIST = [
    'uboot',
    'battery',
    'low_battery',
    'charger_ov',
    'num_0',
    'num_1',
    'num_2',
    'num_3',
    'num_4',
    'num_5',
    'num_6',
    'num_7',
    'num_8',
    'num_9',
    'num_percent',
    'bat_animation_01',
    'bat_animation_02',
    'bat_animation_03',
    'bat_animation_04',
    'bat_animation_05',
    'bat_animation_06',
    'bat_animation_07',
    'bat_animation_08',
    'bat_animation_09',
    'bat_animation_10',
    'bat_10_01',
    'bat_10_02',
    'bat_10_03',
    'bat_10_04',
    'bat_10_05',
    'bat_10_06',
    'bat_10_07',
    'bat_10_08',
    'bat_10_09',
    'bat_10_10',
    'bat_bg',
    'bat_img',
    'bat_100',
    'kernel'
]

if os.path.exists(UBOOT_LOGO_FN2):
    RESOURCE_OBJ_LIST.append('uboot2')

obj_list = []
for obj in RESOURCE_OBJ_LIST:
    obj_ = logo_dir+'_'+obj+'.raw'
    if cmp('uboot',obj) == 0 or cmp('kernel',obj) == 0 or cmp('uboot2',obj) == 0:
        obj_list.append(obj_)
    else:
        obj_list.append(os.path.join(logo_dir,obj_))   
    

obj_list_str = ' '.join(obj_list)
#print obj_list_str
def do_cmd(cmd):
    print cmd
    os.system(cmd)

BOOT_LOGO_RAW = logo_dir+'.raw'
UBOOT_RAW = logo_dir+'_uboot.raw'
KERNEL_RAW = logo_dir+'_kernel.raw'
UBOOT2_RAW = logo_dir+'_uboot2.raw'
KERNEL2_RAW = logo_dir+'_kernel2.raw'

if os.path.exists(UBOOT_LOGO_FN):
    gen_uboot_raw = ' '.join([BMP_TO_RAW,UBOOT_RAW,UBOOT_LOGO_FN])
    do_cmd(gen_uboot_raw)
if os.path.exists(KERNEL_LOGO_FN):
    gen_kernel_raw = ' '.join([BMP_TO_RAW,KERNEL_RAW,KERNEL_LOGO_FN])
    do_cmd(gen_kernel_raw)
    gen_boot_logo = ' '.join([BMP_TO_RAW,boot_logo,KERNEL_LOGO_FN])
    do_cmd(gen_boot_logo)
if os.path.exists(UBOOT_LOGO_FN2):
    gen_uboot_raw = ' '.join([BMP_TO_RAW,UBOOT2_RAW,UBOOT_LOGO_FN2])
    do_cmd(gen_uboot_raw)
if os.path.exists(KERNEL_LOGO_FN2):
    gen_kernel_raw = ' '.join([BMP_TO_RAW,KERNEL2_RAW,KERNEL_LOGO_FN2])
    do_cmd(gen_kernel_raw)
    gen_boot_logo = ' '.join([BMP_TO_RAW,boot_logo2,KERNEL_LOGO_FN2])
    do_cmd(gen_boot_logo)

zpipe_cmd = ' '.join([ZPIPE,'-l 9',BOOT_LOGO_RAW,obj_list_str])
do_cmd(zpipe_cmd)

mkimage_cmd = ' '.join([MKIMAGE,BOOT_LOGO_RAW,'LOGO >',logo_bin])
do_cmd(mkimage_cmd)

del_tmp_files = ' '.join(['rm',BOOT_LOGO_RAW,UBOOT_RAW,KERNEL_RAW,UBOOT2_RAW,KERNEL2_RAW])
do_cmd(del_tmp_files)
