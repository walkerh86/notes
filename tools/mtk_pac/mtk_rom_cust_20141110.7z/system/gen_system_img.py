#!/usr/bin/python

import os
import sys
import ConfigParser
from sys import path
path.append('..')
import cust_rom

def do_cmd(cmd):
    print cmd
    os.system(cmd)

def show_usage():
    print \
'Usage:\
    <--system/--userdata>\
    -unpack <src_system_img>\
    -repack <dst_system_img>\
    -modify logo <src_boot_dir>\
            overlay <src_dir>\
            props <props_list>\
            preinstall_app <preinstall_dir>\
            prebuilt_app <prebuilt_dir>\
    '
    
SIMG2IMG = os.path.join('tools','simg2img')
MKYAFFS2IMAGE = os.path.join('tools','mkyaffs2image')

SYSTEM_EXT_IMG = 'system.ext.img'
SYSTEM_MOUNT_DIR = 'system'
SYSTEM_IMG_INFO = 'system_image_info.txt'

USERDATA_EXT_IMG = 'userdata.ext.img'
USERDATA_MOUNT_DIR = 'data'
USERDATA_IMG_INFO = 'userdata_image_info.txt'

#unpack system.img
def unpack_img(src_img, ext_img, mount_dir):
    print 'system unpack_img......'
    do_cmd(' '.join([SIMG2IMG,src_img,ext_img]))
    
    if not os.path.exists(mount_dir):
        os.mkdir(mount_dir)

    mount_cmd = ' '.join(['sudo','mount -o loop',ext_img,mount_dir])
    do_cmd(mount_cmd)

#repack system.img
def repack_img(dst_img, ext_img, mount_dir, img_info):
    print 'system repack_img......'
    BUILD_IMAGE = os.path.join('tools','build_image.py')
    BUILD_PROPERTY = os.path.join('tools',img_info)
    build_cmd = ' '.join(['sudo',BUILD_IMAGE,mount_dir,BUILD_PROPERTY,dst_img])
    do_cmd(build_cmd)

    unmount_cmd = ' '.join(['sudo','umount',mount_dir])
    do_cmd(unmount_cmd)

    #rm temp files
    do_cmd(' '.join(['rm',ext_img]))
    do_cmd(' '.join(['rm -rf',mount_dir]))

def cp_file(src_file,dst_dir):
    cp_cmd = ' '.join(['sudo cp',src_file,dst_dir])
    do_cmd(cp_cmd)
    
def modify_logo(src_boot_logo_dir):
    print 'system modify_logo......'
    boot_logos = ['boot_logo','boot_logo2']
    for boot_logo in boot_logos:
        src_boot_logo = os.path.join(src_boot_logo_dir,boot_logo)
        if os.path.exists(src_boot_logo):
            DST_BOOT_LOGO = os.path.join(SYSTEM_MOUNT_DIR,'media','images',boot_logo)
            boot_logo_cmd = ' '.join(['sudo cp',src_boot_logo,DST_BOOT_LOGO])
            do_cmd(boot_logo_cmd)
            do_cmd('rm '+src_boot_logo)

def modify_overlay(src_dir):
    print 'system modify_overlay......'
    dir_name = os.path.basename(src_dir)
    tmp_src_dir = os.path.join(src_dir,'*')
    do_cmd('sudo chmod 777 -R '+dir_name)
    if src_dir.endswith('data'):
        src_dir = os.path.join(src_dir,'app')
        dst_dir = os.path.join(USERDATA_MOUNT_DIR,'app')
        if os.path.exists(src_dir) and os.path.exists(dst_dir):
            do_cmd(' '.join(['sudo rm -rf',dst_dir]))
    if src_dir.endswith('system'):
        src_dir = os.path.join(src_dir,'appbackup')
        dst_dir = os.path.join(SYSTEM_MOUNT_DIR,'appbackup')
        if os.path.exists(src_dir) and os.path.exists(dst_dir):
            do_cmd(' '.join(['sudo rm -rf',dst_dir]))
    do_cmd(' '.join(['sudo cp -r',tmp_src_dir,dir_name]))

def modify_props(props):
    print 'system modify_props......'
    SRC_BUILD_PROP = os.path.join(SYSTEM_MOUNT_DIR,'build.prop')
    TMP_BUILD_PROP = 'build.prop'
    cust_rom.do_modify_prop_cb(SRC_BUILD_PROP,TMP_BUILD_PROP,props)

def modify_preinstall_app(preinstall_dir):
    print 'system modify_preinstall_app......'
    SYSTEM_APPBACKUP_DIR = os.path.join('system','appbackup')+'/'
    if os.path.exists(SYSTEM_APPBACKUP_DIR):
        do_cmd('sudo rm -rf '+SYSTEM_APPBACKUP_DIR)
    do_cmd('sudo mkdir '+SYSTEM_APPBACKUP_DIR)
    src_files = preinstall_dir+'/*.apk'
    do_cmd(' '.join(['sudo cp',src_files,SYSTEM_APPBACKUP_DIR]))

    DATA_APP_DIR = os.path.join('data','app')+'/'
    if os.path.exists(DATA_APP_DIR):
        do_cmd('sudo rm -rf '+DATA_APP_DIR)
    do_cmd('sudo mkdir '+DATA_APP_DIR)
    src_files = preinstall_dir+'/*'
    src_hide_files = preinstall_dir+'/.*'
    do_cmd(' '.join(['sudo cp ',src_files,DATA_APP_DIR]))
    do_cmd(' '.join(['sudo cp ',src_hide_files,DATA_APP_DIR]))
    
def modify_prebuilt_app(prebuilt_dir):
    print 'system modify_prebuilt_app......'
    SYSTEM_APP_DIR = os.path.join('system','app')+'/'
    SYSTEM_LIB_DIR = os.path.join('system','lib')+'/'
    apps = os.listdir(prebuilt_dir)
    for app in apps:
        src_file = os.path.join(prebuilt_dir,app)
        if app.endswith('.apk'):
            cp_file(src_file,SYSTEM_APP_DIR)
        elif app.endswith('.so'):
            cp_file(src_file,SYSTEM_LIB_DIR)
    
def modify_img(argv):
    print 'system modify_img......'
    modify_part = argv[0]
    if cmp(modify_part,'logo') == 0:
        modify_logo(argv[1])
    elif cmp(modify_part,'overlay') == 0:
        modify_overlay(argv[1])
    elif cmp(modify_part,'props') == 0:
        modify_props(argv[1:])
    elif cmp(modify_part,'preinstall_app') == 0:
        modify_preinstall_app(argv[1])
    elif cmp(modify_part,'prebuilt_app') == 0:
        modify_prebuilt_app(argv[1])

if len(sys.argv) < 3:
    show_usage()
    sys.exit()

is_system = (cmp(sys.argv[1],'--system') == 0)
ext_img = ''
mount_dir = ''
img_info = ''
if is_system:
    ext_img = SYSTEM_EXT_IMG
    mount_dir = SYSTEM_MOUNT_DIR
    img_info = SYSTEM_IMG_INFO
else:
    ext_img = USERDATA_EXT_IMG
    mount_dir = USERDATA_MOUNT_DIR
    img_info = USERDATA_IMG_INFO
    
cmd = sys.argv[2]
if cmp(cmd,'-unpack') == 0:
    unpack_img(sys.argv[3],ext_img,mount_dir)
elif cmp(cmd,'-repack') == 0:
    repack_img(sys.argv[3],ext_img,mount_dir,img_info)
elif cmp(cmd,'-modify') == 0:
    modify_img(sys.argv[3:])
    
