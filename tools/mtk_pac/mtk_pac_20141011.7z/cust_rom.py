#!/usr/bin/python

import os
import sys
import ConfigParser

def do_cmd(cmd):
    print cmd
    os.system(cmd)
    
LOGO_DIR = 'logo'
SYSTEM_DIR = 'system'
USERDATA_DIR = 'userdata'
RECOVERY_DIR = 'recovery'
CUSTOM_DIR = 'zcustom'

GEN_LOGO_BIN = 'gen_logo.py'
GEN_SYSTEM_BIN = 'gen_system_img.py'
GEN_USERDATA_BIN = 'gen_userdata_img.py'
GEN_RECOVERY_BIN = 'gen_recovery_img.py'

CUST_OUT = os.path.join(CUSTOM_DIR,'out')
CUST_LOGO = os.path.join(CUSTOM_DIR,'logo.bmp')
CUST_BOOT_ANIM = os.path.join(CUSTOM_DIR,'bootanimation.zip')
CUST_BOOT_SOUND = os.path.join(CUSTOM_DIR,'bootaudio.mp3')
CUST_SYSTEM_APP = os.path.join(CUSTOM_DIR,'system_app')
CUST_PREINSTALL_APP = os.path.join(CUSTOM_DIR,'preinstall_app')
CUST_CONFIG = os.path.join(CUSTOM_DIR,'cust_config')

CUST_OUT_BOOTLOGO = os.path.join(CUST_OUT,'boot_logo')

logo_dir = 'wsvganl'

#init configs
CONF_SECTION_BOARD = 'board'
CONF_SECTION_CUST = 'custom'

src_bin_dir = ''
cust_props = ''

def show_usage():
    print 'Usage:'
    
def init_check_argvs():
    global src_bin_dir
    
    if len(sys.argv) < 2:
        show_usage()
        sys.exit()

    src_bin_dir = sys.argv[1]
    
def conf_parser_get(parse, section, option):
    try:
        return parse.get(section,option)
    except:
        return ''
        
def init_configs():
    global cust_props
    global logo_dir
    conf_parser = ConfigParser.ConfigParser()
    conf_parser.read(CUST_CONFIG)
    if src_bin_dir.find('LD') > -1:
        logo_dir = 'wvgalnl'
        
    cust_brand = conf_parser_get(conf_parser,CONF_SECTION_CUST,'brand')
    cust_model = conf_parser_get(conf_parser,CONF_SECTION_CUST,'model')
    cust_version = conf_parser_get(conf_parser,CONF_SECTION_CUST,'version')
    if len(cust_model) > 0:
        cust_props += 'ro.product.model='+cust_model+' '
    if len(cust_brand) > 0:
        cust_props += 'ro.product.brand='+cust_brand+' '
    if len(cust_version) > 0:
        cust_props += 'ro.build.display.id='+cust_version+' '
    
#check dep
modify_logo = False
modify_system = False
modify_userdata = False
modify_recovery = False

def check_logo_dep():
    if os.path.exists(CUST_LOGO):
        return True
    return False

def check_prop_dep():
    if len(cust_props) > 0:
        return True
    return False

def check_system_dep():
    if os.path.exists(CUST_LOGO):
        return True
    if os.path.exists(CUST_BOOT_ANIM):
        return True
    if len(os.listdir(CUST_SYSTEM_APP)) > 0:
        return True
    if len(os.listdir(CUST_PREINSTALL_APP)) > 0:
        return True
    return check_prop_dep()

def check_userdata_dep():
    if len(os.listdir(CUST_PREINSTALL_APP)) > 0:
        return True
    return False

def check_recovery_dep():
    return check_prop_dep()

def init_check_dep():
    global modify_logo
    global modify_system
    global modify_userdata
    global modify_recovery
    modify_logo = check_logo_dep()
    modify_system = check_system_dep()
    modify_userdata = check_userdata_dep()
    modify_recovery = check_recovery_dep()
    
def init_check():
    if not os.path.exists(src_bin_dir):
        sys.exit('src bin dir '+src_bin_dir+' not exists')

    if modify_system and not os.path.exists(os.path.join(src_bin_dir,'system.img')):
        sys.exit('system.img not exists')
        
    if modify_userdata and not os.path.exists(os.path.join(src_bin_dir,'userdata.img')):
        sys.exit('userdata.img not exists')

    if modify_recovery and not os.path.exists(os.path.join(src_bin_dir,'recovery.img')):
        sys.exit('recovery.img not exists')
    
    if os.path.exists(CUST_OUT):
        do_cmd('rm -rf '+CUST_OUT)
    os.mkdir(CUST_OUT)

    do_cmd('sudo chmod 777 '+os.path.join(SYSTEM_DIR,GEN_SYSTEM_BIN))
    do_cmd('sudo chmod 777 '+os.path.join(RECOVERY_DIR,GEN_RECOVERY_BIN))
    do_cmd('sudo chmod 777 '+os.path.join(LOGO_DIR,GEN_LOGO_BIN))
    
#gen logo
def gen_logo_img():
    os.chdir(LOGO_DIR)
    tmp_cust_logo = os.path.join('..',CUST_LOGO)
    tmp_cust_out = os.path.join('..',CUST_OUT)
    gen_logo_cmd = ' '.join(['python',GEN_LOGO_BIN,logo_dir,tmp_cust_logo,tmp_cust_out])
    do_cmd(gen_logo_cmd)
    os.chdir('..')

def unpack_system_img():
    os.chdir(SYSTEM_DIR)
    src_img = os.path.join('..',src_bin_dir,'system.img')
    unpack_system_img_cmd = ' '.join(['python',GEN_SYSTEM_BIN,'--system','-unpack',src_img])
    do_cmd(unpack_system_img_cmd)
    os.chdir('..')

def repack_system_img():
    os.chdir(SYSTEM_DIR)
    dst_img = os.path.join('..',CUST_OUT,'system.img')
    repack_system_img_cmd = ' '.join(['python',GEN_SYSTEM_BIN,'--system','-repack',dst_img])
    do_cmd(repack_system_img_cmd)
    os.chdir('..')

def unpack_userdata_img():
    os.chdir(SYSTEM_DIR)
    src_img = os.path.join('..',src_bin_dir,'userdata.img')
    unpack_system_img_cmd = ' '.join(['python',GEN_SYSTEM_BIN,'--userdata','-unpack',src_img])
    do_cmd(unpack_system_img_cmd)
    os.chdir('..')

def repack_userdata_img():
    os.chdir(SYSTEM_DIR)
    dst_img = os.path.join('..',CUST_OUT,'userdata.img')
    repack_system_img_cmd = ' '.join(['python',GEN_SYSTEM_BIN,'--userdata','-repack',dst_img])
    do_cmd(repack_system_img_cmd)
    os.chdir('..')

def unpack_recovery_img():
    os.chdir(RECOVERY_DIR)
    src_img = os.path.join('..',src_bin_dir,'recovery.img')
    unpack_img_cmd = ' '.join(['python',GEN_RECOVERY_BIN,'-unpack',src_img])
    do_cmd(unpack_img_cmd)
    os.chdir('..')

def repack_recovery_img():
    os.chdir(RECOVERY_DIR)
    dst_img = os.path.join('..',CUST_OUT,'recovery.img')
    repack_img_cmd = ' '.join(['python',GEN_RECOVERY_BIN,'-repack',dst_img])
    do_cmd(repack_img_cmd)
    os.chdir('..')
    
def unpack_imgs():
    if modify_system:
        unpack_system_img()
    if modify_recovery:
        unpack_recovery_img()
    if modify_userdata:
        unpack_userdata_img()

def repack_imgs():
    if modify_system:
        repack_system_img()
    if modify_recovery:
        repack_recovery_img()
    if modify_userdata:
        repack_userdata_img()

def do_modify_logo():
    if not os.path.exists(CUST_LOGO):
        return
    #gen logo.bin & boot_logo
    gen_logo_img()
    
    os.chdir(SYSTEM_DIR)
    modify_logo_cmd = ' '.join(['python',GEN_SYSTEM_BIN,'--system','-modify','logo',os.path.join('..',CUST_OUT_BOOTLOGO)])
    do_cmd(modify_logo_cmd)
    os.chdir('..')

def do_modify_bootanim():
    boot_files = ''
    if os.path.exists(CUST_BOOT_ANIM):
        boot_files += os.path.join('..',CUST_BOOT_ANIM)+' '
    if os.path.exists(CUST_BOOT_SOUND):
        boot_files += os.path.join('..',CUST_BOOT_SOUND)+' '
    if len(boot_files) == 0:
        return
    os.chdir(SYSTEM_DIR)
    modify_bootanim_cmd = ' '.join(['python',GEN_SYSTEM_BIN,'--system','-modify','bootanim',boot_files])
    do_cmd(modify_bootanim_cmd)
    os.chdir('..')

def do_modify_prop_cb(src_prop, tmp_prop, prop_list):
    props_dict = {}
    for prop in prop_list:
        if len(prop.strip()) == 0:
            continue
        prop_pair = prop.split('=')
        if len(prop_pair) != 2:
            continue
        props_dict[prop_pair[0]] = prop_pair[1]
        
    src_prop_f = open(src_prop,'r')
    tmp_prop_f = open(tmp_prop,'w')
    for line in src_prop_f:
        strip_line = line.strip()
        line_pair = strip_line.split('=')
        if len(line_pair) == 2 and props_dict.has_key(line_pair[0]):
            tmp_prop_f.write(line_pair[0]+'='+props_dict[line_pair[0]]+'\n')
        else:
            tmp_prop_f.write(line)
    src_prop_f.close()
    tmp_prop_f.close()
    do_cmd(' '.join(['sudo mv',tmp_prop,src_prop]))
    
def do_modify_prop():
    if not check_prop_dep():
        return
    os.chdir(SYSTEM_DIR)
    modify_props_cmd = ' '.join(['python',GEN_SYSTEM_BIN,'--system','-modify','props',cust_props])
    do_cmd(modify_props_cmd)
    os.chdir('..')
    os.chdir(RECOVERY_DIR)
    modify_props_cmd = ' '.join(['python',GEN_RECOVERY_BIN,'-modify','props',cust_props])
    do_cmd(modify_props_cmd)
    os.chdir('..')

def do_modify_prebuilt_app():
    if len(os.listdir(CUST_SYSTEM_APP)) == 0:
        return
    os.chdir(SYSTEM_DIR)
    modify_system_app_cmd = ' '.join(['python',GEN_SYSTEM_BIN,'--system','-modify','prebuilt_app',os.path.join('..',CUST_SYSTEM_APP)])
    do_cmd(modify_system_app_cmd)
    os.chdir('..')

def do_modify_preinstall_app():
    preinstall_apps = os.listdir(CUST_PREINSTALL_APP)
    if len(preinstall_apps) == 0:
        return
    #gen .keep_list & .restore_list
    keep_list = []
    for app in preinstall_apps:
        keep_list.append('/data/app/'+app+'\n')
    keep_list_f = open(os.path.join(CUST_PREINSTALL_APP,'.keep_list'),'w')
    keep_list_f.writelines(keep_list)
    keep_list_f.close()
    restore_list = []
    for app in preinstall_apps:
        restore_list.append('/system/appbackup/'+app+'\n')
    restore_list_f = open(os.path.join(CUST_PREINSTALL_APP,'.restore_list'),'w')
    restore_list_f.writelines(restore_list)
    restore_list_f.close()
    
    os.chdir(SYSTEM_DIR)
    modify_preinstall_app_cmd = ' '.join(['python',GEN_SYSTEM_BIN,'--system','-modify','preinstall_app',os.path.join('..',CUST_PREINSTALL_APP)])
    do_cmd(modify_preinstall_app_cmd)
    os.chdir('..')
    
def modify_imgs():
    do_modify_logo()
    do_modify_bootanim()
    do_modify_prop()
    do_modify_prebuilt_app()
    do_modify_preinstall_app()

def main(argv):
    init_check_argvs()
    init_configs()
    init_check_dep()
    init_check()
    unpack_imgs()
    modify_imgs()
    repack_imgs()
    
if __name__ == '__main__':
    main(sys.argv)
