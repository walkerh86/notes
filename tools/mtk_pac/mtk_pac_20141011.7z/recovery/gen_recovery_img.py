#!/usr/bin/python

import os
import sys
from sys import path
path.append('..')
import cust_rom

def do_cmd(cmd):
    print cmd
    os.system(cmd)

def show_usage():
    print \
'Usage:\
    -unpack <src_system_img>\
    -repack <dst_system_img>\
    -modify props <props_list>\
    '
    
MOUNT_DIR = 'recovery.img-ramdisk'

#unpack recovery.img
def unpack_img(src_img):
    print 'recovery unpack_img......'
    unpack_bin = os.path.join('tools','unpack-MT65xx.pl')
    unpack_cmd = ' '.join([unpack_bin,src_img])
    do_cmd(unpack_cmd)

#repack recovery.img
def repack_img(dst_img):
    print 'recovery repack_img......'
    MKBOOTFS = os.path.join('tools','mkbootfs')
    MINIZIP = os.path.join('tools','minigzip')
    MKIMAGE = os.path.join('tools','mkimage')
    MKBOOTIMAGE = os.path.join('tools','mkbootimg')

    RAMDISK_DIR = 'recovery.img-ramdisk'
    RAMDISK_IMG_TMP = 'ramdisk-recovery.img'
    RAMDISK_IMG = 'ramdisk_recovery.img'
    KERNEL_IMG = 'recovery.img-kernel.img'

    cmd1 = ' '.join([MKBOOTFS,RAMDISK_DIR,'|',MINIZIP,'>',RAMDISK_IMG_TMP])
    cmd2 = ' '.join([MKIMAGE,RAMDISK_IMG_TMP,'RECOVERY','>',RAMDISK_IMG])
    cmd3 = ' '.join(['mv',RAMDISK_IMG,RAMDISK_IMG_TMP])
    cmd4 = ' '.join([MKBOOTIMAGE,'--kernel',KERNEL_IMG,'--ramdisk',RAMDISK_IMG_TMP,'--output',dst_img])
    do_cmd(cmd1)
    do_cmd(cmd2)
    do_cmd(cmd3)
    do_cmd(cmd4)

    do_cmd('rm -rf recovery.img-ramdisk recovery.img-kernel.img ramdisk-recovery.img')

def modify_props(props):
    print 'recovery modify_props......'
    SRC_BUILD_PROP = os.path.join(MOUNT_DIR,'default.prop')
    TMP_BUILD_PROP = 'default.prop'
    cust_rom.do_modify_prop_cb(SRC_BUILD_PROP,TMP_BUILD_PROP,props)
    
def modify_img(argv):
    print 'recovery modify_img......'
    modify_part = argv[0]
    if cmp(modify_part,'props') == 0:
        modify_props(argv[1:])
        
def main(argv):
    cmd = sys.argv[1]
    if cmp(cmd,'-unpack') == 0:
        unpack_img(sys.argv[2])
    elif cmp(cmd,'-repack') == 0:
        repack_img(sys.argv[2])
    elif cmp(cmd,'-modify') == 0:
        modify_img(sys.argv[2:])
    
if __name__ == '__main__':
    if len(sys.argv) < 2:
        show_usage()
        sys.exit()
    main(sys.argv)
